from scipy.signal import find_peaks, butter, sosfiltfilt, savgol_filter, lfilter
from scipy.io import loadmat
import numpy as np
import matplotlib.pyplot as plt
import statistics
import scipy.optimize._dual_annealing
from scipy.fft import fft, ifft
import pandas as pd
from sklearn.model_selection import KFold
from sklearn.metrics.pairwise import euclidean_distances

#Spike_funcations - store and maniuplate spike data, as well as spike index and class data
class Spike_object:

    # set variables
    def __init__(self, data=None, index=None, classes=None):
        self.data = data
        self.index = index
        self.classes = classes
        #self.

    # Load mat file
    def load_data(self, file, train=False):
        data_set = loadmat(file, squeeze_me=True)

        self.data = data_set['d']

        # load known index and class data only if training file
        if train:        
            self.index = data_set['Index']
            self.classes = data_set['Class']

    # Plots data
    def plot_data(self, x, xlen):
        plt.plot(range(x, x+xlen), self.data[x:x+xlen])
        plt.show()

    # Sort index and class data by index
    def sort(self):        
        sort_zip = sorted(zip(self.index, self.classes))
        self.index, self.classes = map(np.array, zip(*sort_zip))

    # instead of filtering use a spine interpolation function
    def spine_interpolation(self):
        # Find the indices of the local maxima of the signal
        max_indices = np.argpartition(self.data, -2)[-2:]
        max_indices = max_indices[np.argsort(self.data[max_indices])][::-1]
        
        # Interpolate the signal using the local maxima
        x = np.arange(len(self.data))
        interp = np.interp(x, max_indices, self.data[max_indices])
        self.data = interp

    # savitzky_golay_filter (output similar to low pass filter)
    def savitzky_golay_filter(self, window_size, polynomial_order):
        # apply the Savitzky-Golay filter to the data
        filtered_data = savgol_filter(self.data, window_size, polynomial_order)
        self.data = filtered_data
        
    # bandpass filter using the fourier transform
    def bandpass_filter(self, min_frequency, max_frequency):
        # Apply a Fourier transform to the signal to convert it to the frequency domain
        frequency_spectrum = fft(self.data)

        # Create a mask that will only keep the frequencies within the specified range
        mask = np.zeros(len(frequency_spectrum))
        mask[min_frequency:max_frequency] = 1

        # Apply the mask to the frequency spectrum to filter the signal
        filtered_spectrum = frequency_spectrum * mask

        # Apply an inverse Fourier transform to convert the filtered spectrum back to the time domain
        filtered_signal = ifft(filtered_spectrum)

        #self.data = filtered_signal 
        return filtered_signal

    # specilaised bandpass filter function
    def BP_filter(self, low_cut,high_cut,sampling_freq,order=2):

        nyq = 0.5 * sampling_freq
        low = low_cut / nyq
        high = high_cut / nyq
        b, a = butter(order, [low, high], btype='band')

        filtered=lfilter(b,a,self.data)
        self.data = filtered

        return filtered
    
    # Apply filter to recording data
    def filter(self, cutoff, type, fs=25e3, order=2):
        
            # Low pass butterworth filter
        sos = butter(order, cutoff, btype=type, output='sos', fs=fs)
        filtered = sosfiltfilt(sos, self.data)
        self.data = filtered   

    # Create window for class identification
    def create_window(self, window_size=46, offset = 15):
        windows = np.zeros((len(self.index), window_size))
        
        # Loop through each spike index
        for i, index in enumerate(self.index):       

            # Slice data array to get window     
            data = self.data[int(index-offset):int(index+window_size-offset)]

            windows[i, :] = data
        return windows
    
    # measures the averarge noise in a window and 
    # returns a threshold depenmding on this
    def adaptive_threshold(self, window_size = 10):
        noise_est = []
        clean_indices = []

        for i in range(len(self.data)-10):
            ratio = self.data[i]/self.data[i+window_size]
            if ratio < 1 and np.abs(self.data[i+window_size]) > 2:
                clean_indices.append(i)
            
            if len(clean_indices) == 250:
                for i in clean_indices:
                    window = self.data[i:i+window_size]
                    noise_est.append(np.abs(statistics.variance(window)))
                break

        threshold = np.median(noise_est) 
        # print(threshold)
        return (threshold)

    # get rolling medium of signal and subtract it to faltten signal, bandpass filter works better
    def messy_signal(self, RM_window=500):
        signalDF=pd.DataFrame(self.data)
        median=signalDF.rolling(window=RM_window, min_periods=1).median().to_numpy()
        for i in range(len(self.data)): 
            self.data[i] = self.data[i] - median[i][0]
        
        self.plot_data(0, len(self.data))
    
    # find spikes using prominance
    def find_spikes(self, low_cut=0, high_cut=0, xprominence =5, wlen=30, sampling_freq=25e6):
        
        if low_cut != 0:
            self.data = self.BP_filter(low_cut,high_cut,sampling_freq)

        MAD=scipy.stats.median_abs_deviation(self.data)
        
        peaks, _ = find_peaks(self.data , prominence=xprominence*MAD, wlen=wlen)#height = threshold)
        self.index = peaks

        return peaks

    # find peaks using an amplitude threshold
    def find_spike(self):
        # Initialize a list to store the start indices of the spikes

        threshold = self.adaptive_threshold()
        
        peaks, _ = find_peaks(self.data , height = threshold)
        self.index = peaks
        return peaks


    # Define the peak detection function
    def detect_peaks(self, xprominence, wlen):
        MAD=scipy.stats.median_abs_deviation(self.data)

        peaks,_ = find_peaks(self.data, prominence=xprominence*MAD, wlen=wlen)

        return peaks

    # function to prounces the peaks further for better peak identification
    def enhance_peaks(self):

        # Apply the logarithmic transformation to the signal
        enhanced_signal = np.log(self.data)

        self.data = enhanced_signal

    # Spilt one spike data set into 2 (training/validation)
    def split_data(self, percent):
        # Get index to split at
        index = int(len(self.data)*(1.0-percent))
        # Slice data
        split_data = self.data[index:]
        self.data = self.data[:index]

        # Slice spike and class index data
        i = int(np.argmax(self.index >= index))        
        split_spikes = self.index[i:] - index
        self.index = self.index[:i]
        split_classes = self.classes[i:]
        self.classes = self.classes[:i]        

        # Construct new Spike_object object with sliced data and return
        return Spike_object(split_data, split_spikes, split_classes)

    
    # If data is training data, compare found spikes with known index/class 
    def compare(self, range=50):
        # Get spikes from training data
        known_index = self.index

        # find spikes in data
        #found_index = self.find_spikes()
        #found_index = self.find_spike_start()
        found_index = self.find_spike()
        #found_index = self.find_spike_start(found_index)

        # create empty arrays with corrrect sizes
        spikes = np.zeros(len(found_index))
        classes = np.zeros(len(found_index))

        # Loop through found indices
        for i, spike in enumerate(found_index):
            # find where found spike is in know spike array
            # confirm if found spikes are approximatly correct (within range of 50 above or below)
            found = np.where((known_index > spike - range) & (known_index < spike + range))[0]
            
            # if a spike is confirmed 
            if len(found) > 0:

                # Mark as correct in spike array
                spikes[i] = spike
                
                # find difference between where the found spike is and its known position
                diff = abs(known_index[found] - spike)

                # get index of the min corresponding spike
                index = found[np.argmin(diff)]

                # if index exists in self.classes
                if index < len(self.classes):
                    # assign class to be same as the peak found
                    classes[i] = self.classes[index]

                # Remove from selection to prevent repeats
                known_index[index] = 0

        # remove all undetected spikes and the corresponding class from the array
        spikes = spikes[spikes != 0]
        classes = classes[classes != 0]

        # overwrite 
        self.index = spikes
        self.classes = classes

        # Score spike detecttion
        spike_score = (len(spikes) / len(known_index))

        return spike_score
    
    # secondary method for comparing found peaks to known peaks
    def compare_peaks(self, classifier, range=50):
        # Get spikes from training data
        known_peaks = self.index

        # find spikes in data
        found_peaks = self.find_spikes()
        #found_peaks = self.detect_peaks()
        
        # Classify the found peaks using the trained classifier
        found_classes = classifier.predict(found_peaks)

        # Calculate the Euclidean distances between the found and known peaks
        distances = euclidean_distances(found_peaks, known_peaks)

        # Find the minimum distance for each found peak
        min_distances = np.min(distances, axis=1)

        # Determine which found peaks have a minimum distance below the threshold
        below_threshold = min_distances < range

        # Remove the found peaks and their corresponding classes that do not have a minimum distance below the threshold
        correct_found_peaks = found_peaks[below_threshold]
        correct_found_classes = found_classes[below_threshold]

        return correct_found_peaks, correct_found_classes

    # method to verify the performance of the KNN
    def cross_validate(self, classifier, num_folds=5):
        # Split the data into folds
        kf = KFold(n_splits=num_folds)

        # Initialize a list to store the classifier's performance on each fold
        scores = []

        # Loop through the folds
        for train_index, test_index in kf.split(self.data):
            # Split the data into training and test sets
            X_train, X_test = self.data[train_index], self.data[test_index]
            y_train, y_test = self.classes[train_index], self.classes[test_index]

            # Train the classifier on the training set
            classifier.fit(X_train, y_train)

            # Evaluate the classifier's performance on the test set
            score = classifier.score(X_test, y_test)
            scores.append(score)

        # Calculate the mean and standard deviation of the classifier's performance across the folds
        mean_score = np.mean(scores)
        std_dev = np.std(scores)

        return mean_score, std_dev
