import os
import numpy as np
from scipy.io import savemat
from scipy.optimize import dual_annealing
from sklearn.metrics import confusion_matrix, classification_report
from sklearn.neighbors import KNeighborsClassifier

# import class with all made functions
from spike_functions import Spike_object

class Spike_sort_KNN:

    def __init__(self, verbose=True):        
        # initiate k nearest neighbour classifier
        self.n = KNeighborsClassifier(n_neighbors=5, p=2)
        self.verbose = verbose
        self.target = 1
        self.folder_name = 'Results5'
        os.mkdir(self.folder_name)
        
    # train nn with training data D1
    def train(self):       

        # initiate Spike_object for training data
        self.training = Spike_object()

        # retrieve data in the training data set 
        self.training.load_data('D1.mat', train=True)  
        
        #self.training.plot_data(0,len(self.training.data))
        #self.training.plot_data(1062, 500)

        # Sort index/class data 
        self.training.sort()
        
        # Take last 20% of training data set and use as a validation data set
        self.validation = self.training.split_data(0.2)

        #self.training.enhance_peaks()
        #self.validation.enhance_peaks()

        # Filter the input data
        #self.training.filter(2500, 'low') 
        #self.validation.filter(2500, 'low')
        #self.training.filter([10,1200], 'band')
        #self.validation.filter([10,1200], 'band')
        self.training.savitzky_golay_filter(25, 5)
        self.validation.savitzky_golay_filter(25, 5)

        self.n.fit(self.training.create_window(), self.training.classes)
        
        
        # Run spike detection and comparison on training data
        self.training.compare()
        #self.training.compare_peaks(self.n)

        # train nn with training dataset known classes        
        self.n.fit(self.training.create_window(), self.training.classes)

    # measure performace of nn
    def validate(self):     
        # spike detection and comparison on validation data
        spike_score = self.validation.compare()  

        #mean_score, std_dev = self.validation.cross_validate(self.n)

        # predict class detected spikes
        predict = self.n.predict(self.validation.create_window())

        # compare to known classes
        classified = np.where(predict == self.validation.classes)[0]

        # score output
        class_score = (len(classified) / len(self.validation.index))

        #Performance metrics
        if self.verbose:
            print(f'Spike detection score: {spike_score:.4f}')
            print(f'Class detection score: {class_score:.4f}')
            print(f'Overall score:{(spike_score*class_score):.4f}')
            #print('Mean Score: ', mean_score)
            #print('Standard deviation: ', std_dev)

            confusion = confusion_matrix(self.validation.classes, predict)
            print(confusion)
            class_results = classification_report(self.validation.classes, predict, digits=4)
            print(class_results)

        return class_score

    # run test files with trained nn 
    def output(self, input_file, output_file, file_num=3):

        self.outputs = Spike_object()
        
        self.outputs.load_data(input_file, train=False)

        self.outputs.plot_data(0, len(self.outputs.data))
        #self.outputs.plot_data(1062,500)

        # Filter data with band pass as data is very noisy
        if file_num == 2:
            #self.outputs.savitzky_golay_filter(25, 5)
            self.target = 2354
        elif file_num == 3:
            self.target = 3614
            #self.outputs.filter([150,2500], 'band')
        
        ## filter and find peaks depending on input file
        if file_num == 1:
            da_iterations=1000
            low_cut_bounds=[50,150]
            high_cut_bounds=[2000,3500]
            xprominence_bounds=[1,6]
            wlen_bounds=[25,150]
            sampling_freq_bounds=[25000,50000]

            bounds=[low_cut_bounds,high_cut_bounds,xprominence_bounds,wlen_bounds,sampling_freq_bounds]

            # Use the duel_annealing function to find the optimal range of frequencies to use in the bandpass filter
            optimal_frequencies = dual_annealing(self.optimise_filtering,bounds, maxfun=da_iterations)
            print('Best Result  = ', optimal_frequencies.fun)
            print('Low Frequency = ', optimal_frequencies.x[0],', High Frequency = ', optimal_frequencies.x[1], ', Prominence Multiplier= ', optimal_frequencies.x[2], ', Wlen = ', optimal_frequencies.x[3], ', Sampling Frequency =', optimal_frequencies.x[4])
            
            # Apply the bandpass filter with the optimal frequency range
            self.outputs.filter( [optimal_frequencies.x[0],optimal_frequencies.x[1]], 'band')
            self.outputs.plot_data(0, len(self.outputs.data))
        
            spikes = self.outputs.detect_peaks(optimal_frequencies.x[2], optimal_frequencies.x[3])
        elif file_num == 2:
            #self.outputs.filter(3200, 'low')
            self.outputs.savitzky_golay_filter(25, 5)
            self.outputs.plot_data(0, len(self.outputs.data))
            #self.outputs.plot_data(1062,500)
            
            spikes = self.outputs.find_spike()

        elif file_num == 3:
            self.outputs.filter([10,2000], 'band')
            #self.outputs.filter(3200, 'low')
            self.outputs.plot_data(0, len(self.outputs.data))
            #self.outputs.plot_data(1062,500)
            
            spikes = self.outputs.find_spikes()

        print(f'{len(spikes)} spikes detected')
        #self.outputs.plot_data(1062,500)

        # find classes of detected peaks
        predict = self.n.predict(self.outputs.create_window())
        self.outputs.classes = predict      

        print('Class Breakdown')
        self.class_breakdown(predict)

        ## go to results file      
        os.chdir(self.folder_name)

        mat_file = {'D': self.outputs.data,'Index': self.outputs.index, 'Class':predict}
        savemat(output_file, mat_file)

        os.chdir('..')

    # function to print the found classes in the test file
    def class_breakdown(self, classes):
        unique, counts = np.unique(classes, return_counts=True)
        breakdown = dict(zip(unique, counts))

        for key, val in breakdown.items():
            print(f'Type {key:g}: {val}')
        return breakdown
    
    # for duel annealing to find ideal filter values
    def optimise_filtering(self, Inputs):
        
        # get inputs
        low_cut,high_cut,xprominence,wlen,sampling_freq=Inputs
        
        #find spikes
        spikes = self.outputs.find_spikes(low_cut, high_cut, xprominence, wlen, sampling_freq)
        
        # get a score as feed back to measure improvement
        score = abs(self.target-len(spikes))

        return score

if __name__ == '__main__':
    ####### task 1 and 2 ######
    s = Spike_sort_KNN(verbose=True)
    s.train()
    s.validate()
    s.output('D2.mat', 'D2.mat', 2)

    ####### task 3 #########
    s.output('D3.mat', 'D3.mat', 3)

    ####### task 4 #########
    s.output('D4.mat', 'D4.mat', 3)