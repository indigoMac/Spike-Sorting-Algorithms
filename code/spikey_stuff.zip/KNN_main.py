import numpy as np
from scipy.io import savemat
from sklearn.metrics.pairwise import euclidean_distances
#import scipy.optimize.dual_annealing
#import scipy.optimize._dual_annealing as duel_annealing
#from scipy.optimize import _dual_annealing as duel_annealing
#import matplotlib.pyplot as plt
from scipy.fft import fft, ifft
import pywt

# dual annealing global optimization for the ackley multimodal objective function
from scipy.optimize import dual_annealing

from sklearn.metrics import confusion_matrix, classification_report

from sklearn.neighbors import KNeighborsClassifier

from spike_functions import Spike_object

class Spike_sort_KNN:

    def __init__(self, verbose=True):        
        # initiate k nearest neighbour classifier
        self.n = KNeighborsClassifier(n_neighbors=5, p=2)
        self.verbose = verbose
        self.target = 1
        

    def train_knn(self):       

        # Create SpikeData object for training data
        self.training = Spike_object()

        # Load in the training data set 
        self.training.load_data('D1.mat', train=True)  
        
        #self.training_data.plot_data(0,1440000)
        #self.training_data.plot_data(1062, 500)

        # Sort index/class data 
        self.training.sort()
        
        # Take last 20% of training data set and use as a validation data set
        self.validation = self.training.split_data(0.2)

        #self.training_data.enhance_peaks()
        #self.validation_data.enhance_peaks()

        # Filter the raw data
        #self.training_data.filter(2500, 'low') 
        #self.validation_data.filter(2500, 'low')
        self.training.savitzky_golay_filter(25, 5)
        self.validation.savitzky_golay_filter(25, 5)

        self.n.fit(self.training.create_window(), self.training.classes)
        
        #self.training_data.compare_peaks(self.n)
        # Run spike detection and comparison on training data
        self.training.compare()

        # Train the MLP with training dataset classes        
        self.n.fit(self.training.create_window(), self.training.classes)

    def validate_knn(self):     
        # Run spike detection and comparison on validation data
        spike_score = self.validation.compare()  

        #mean_score, std_dev = self.training_data.cross_validate(self.n)

        # Classify detected spikes
        predicted = self.n.predict(self.validation.create_window())
        # Convert probabilties back to class labels (1-5)
        #print(predicted)
        # Compare to known classes
        classified = np.where(predicted == self.validation.classes)[0]

        # Score classifier method
        class_score = (len(classified) / len(self.validation.index))

        #Performance metrics
        if self.verbose:
            print(f'Spike detection score: {spike_score:.4f}')
            print(f'Class detection score: {class_score:.4f}')
            print(f'Overall score:{(spike_score*class_score):.4f}')
            #print('Mean Score: ', mean_score)
            #print('Standard deviation: ', std_dev)

            cm = confusion_matrix(self.validation.classes, predicted)
            print(cm)
            cr = classification_report(self.validation.classes, predicted, digits=4)
            print(cr)

        return class_score


    # Run classifier on submission data set and create submission file
    def output(self, input_file, output_file, file_num=0):
        self.outputs = Spike_object()
        #self.submission_data.load_mat('submission.mat')
        self.outputs.load_data(input_file, train=False)

        #self.outputs.plot_data(0, len(self.outputs.data))
        self.outputs.plot_data(1062,500)

        # Filter data with band pass as data is very noisy
        if file_num == 2:
            #self.submission_data.savitzky_golay_filter(25, 5)
            self.target = 2354
        elif file_num == 3:
            self.target = 3614
            #self.submission_data.filter([150,2500], 'band')
        
        if file_num >= 2:
            dual_annealing_iterations=1000
            low_cut_bounds=[50,150]
            high_cut_bounds=[2000,3500]
            xprominence_bounds=[3,6]
            wlen_bounds=[25,150]
            sampling_freq_bounds=[25000,50000]

            bounds=[low_cut_bounds,high_cut_bounds,xprominence_bounds,wlen_bounds,sampling_freq_bounds]
            #print(bounds)
            # Use the duel_annealing function to find the optimal range of frequencies to use in the bandpass filter
            optimal_frequencies = dual_annealing(self.optimise_filtering,bounds, maxfun=dual_annealing_iterations)
            print('Best Result  = ', optimal_frequencies.fun)
            print('Low cut Frequency = ', optimal_frequencies.x[0],', High cut Frequency = ', optimal_frequencies.x[1], ', Prominence Multiplier= ', optimal_frequencies.x[2], ', Wlen = ', optimal_frequencies.x[3], ', Sampling Frequency =', optimal_frequencies.x[4])
            print('---------------------------------------------------')
            
            # Apply the bandpass filter with the optimal frequency range
            self.outputs.filter( [optimal_frequencies.x[0],optimal_frequencies.x[1]], 'band')
            #print(self.submission_data.data)
            self.outputs.plot_data(0, len(self.outputs.data))
        
            spikes = self.outputs.detect_peaks(optimal_frequencies.x[2], optimal_frequencies.x[3])
        else:
            self.outputs.filter([90,2000], 'band')
            #self.submission_data.filter(3200, 'low')
            #self.submission_data.savitzky_golay_filter(25, 5)
            #self.outputs.plot_data(0, len(self.outputs.data))
            self.outputs.plot_data(1062,500)
            
            spikes = self.outputs.find_spikes()
        print(f'{len(spikes)} spikes detected')
        #self.submission_data.plot_data(1062,500)

        predicted = self.n.predict(self.outputs.create_window())
        self.outputs.classes = predicted      

        print('Class Breakdown')
        self.class_breakdown(predicted)

        
        #mat_file = {'Index': self.submission_data.index, 'Class':predicted}
        mat_file = {'Data': self.outputs.data,'Index': self.outputs.index, 'Class':predicted}
        savemat(output_file, mat_file)


    def class_breakdown(self, classes):
        unique, counts = np.unique(classes, return_counts=True)
        breakdown = dict(zip(unique, counts))

        for key, val in breakdown.items():
            print(f'Type {key:g}: {val}')
        return breakdown
    
    # for duel annealing to find ideal filter values
    def optimise_filtering(self, Inputs):
        
        # get inputs
        low_cut,high_cut,xprominence,wlen,sampling_freq=Inputs
        
        spikes = self.outputs.find_spikes(low_cut, high_cut, xprominence, wlen, sampling_freq)
        score = abs(self.target-len(spikes))

        return score

if __name__ == '__main__':
    ####### task 1 ######
    s = Spike_sort_KNN(verbose=True)
    s.train_knn()
    s.validate_knn()
    s.output('D1.mat', 'D1_out.mat', 1)